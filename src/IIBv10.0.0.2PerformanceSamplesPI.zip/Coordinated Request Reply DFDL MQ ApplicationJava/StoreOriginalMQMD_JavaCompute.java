/*
Sample program for use with IBM Integration Bus
� Copyright International Business Machines Corporation 2012
Licensed Materials - Property of IBM
*/

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;


public class StoreOriginalMQMD_JavaCompute extends MbJavaComputeNode {
	

	public void evaluate(MbMessageAssembly assembly) throws MbException {
		MbMessage message = assembly.getMessage();

		//store the original MQMD in the global cache using the MsgId as the key to 
		//the MQMD header 
		
		// save the MsgID for use as the key to the MQMD stored in the global cache 
		String msgId = message.getRootElement().getFirstElementByPath("/MQMD/MsgId").getValueAsString();
				
		// save the MQMD
		byte[] mqmd = message.getRootElement().getFirstElementByPath("/MQMD").toBitstream(
			null, null, null,
			0, 0, 0
		);

		// Put key and data into map
		MbGlobalMap.getGlobalMap().put(msgId, mqmd);
		
		getOutputTerminal("out").propagate(assembly);
	}

}
